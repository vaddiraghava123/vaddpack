# Vaddi package
A simple vaddpack package