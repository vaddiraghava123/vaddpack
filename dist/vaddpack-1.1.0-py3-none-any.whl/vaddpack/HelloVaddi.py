def __init__(self):
    self.name = "MyClass"

def helloWorld(self,str):
    return "Hello Vaddi Package :: "+ str
    
def newWelcomeMessage(self):
    return "New Vadd Welcome package"