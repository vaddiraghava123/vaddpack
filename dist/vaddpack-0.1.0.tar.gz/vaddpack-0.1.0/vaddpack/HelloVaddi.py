def helloWorld(str):
    return "Hello Vaddi Package :: "+ str